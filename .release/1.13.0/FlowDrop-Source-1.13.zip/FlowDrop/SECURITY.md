# FlowDrop 1.13 security scope

The Windows and Android apps use local temporary storage and direct LAN transfers. A user chooses the destination, and the recipient must accept an incoming offer. Entering a share code is also an explicit receive action.

## Changes in 1.13

- Native Windows control APIs and new upload sessions require a fresh random capability. The native window receives it over its child-process pipe, rather than from an unauthenticated HTTP settings request. The persisted process-state file stays in the user's private application data directory.
- Android upload sessions require a separate per-process capability, passed in process from HostService to the native sender. It is never published in `/api/config`. Creation is also restricted to loopback; knowing this capability does not authorize remote creation.
- Both hosts reject foreign browser origins, cross-site browser requests, unexpected Host headers and proxy-style request targets. Android rejects ambiguous framing, duplicate security headers, invalid chunk sizes and malformed header endings. Headers have an absolute 10-second deadline; file bodies retain idle timeouts, so large active transfers can continue.
- Offer verification has a concurrency bound. Android also closes inactive sockets, including blocked downloads. This bounds concurrent work without imposing a file-size or file-count quota.
- Receivers validate the returned code, UUIDs, unique file IDs, filename/MIME fields, exact numeric sizes, totals and progress data before use. Untrusted status text is bounded before rendering.
- Folder imports keep existing path/CRC checks and now check available storage before expanding each entry, retaining 64 MiB of free space. This is a storage-capacity check, not a fixed transfer quota. Partial imports are rolled back.
- Android sharing accepts user-granted `content://` URIs only. `file://` paths, HTTP URLs and text-only shares are rejected. Sharing opens a selection screen; it never sends automatically. Read grants are forwarded to the foreground sending service instead of requesting broad storage permissions.
- Android 12+ hides third-party overlays while FlowDrop is visible. The receive-confirmation button also filters obscured touches. App backup remains disabled.
- Windows bundles Node 24.22.2 LTS from nodejs.org. The official archive checksum was verified, and the executable checksum is pinned in `desktop/windows/runtime.json` and checked at build time.
- Existing release-signature, HTTPS update-feed, SHA-256, APK package/version/signing-certificate checks remain enabled. Original release/APK signing identities are retained.

## Boundaries

**LAN file traffic still uses HTTP and is not encrypted.** This release does not provide TLS, end-to-end encryption or cryptographic pairing of devices. Device names and discovery IDs are not proof of identity. A network observer may read transferred data; an active network attacker may alter it. Use a trusted network for sensitive files. Update-download security does not encrypt file transfers.

These changes do not provide antivirus scanning or protect against a compromised OS or a malicious process already running as the same Windows account. A share code grants read access until expiry or revocation; keep it private.

Old native Windows/Android peers remain interoperable through offers and share codes. Remote browser clients can no longer create upload sessions on native hosts.

## Validation

- `npm test`: transfer/storage, metadata rejection, browser guards, device names and update choices.
- `npm run test:security`: Windows and Java/Android HTTP attack regressions, private capabilities, remote-write rejection and header deadlines.
- `npm run test:network` and `npm run test:android-host`: production discovery/transfer engines and exact-byte integration.
- `node --test --test-isolation=none tests/folder-receive.test.mjs`: folder integrity, traversal/CRC rejection, ZIP64 above 4 GiB and forged inflated sizes.
- `NativeShareSmoke` is a separate instrumentation APK. Its sender/provider have a different UID from FlowDrop; it checks cold/warm shares, deduplication, permissions and native sending. It is not included in the production APK.
- `tests/windows-shell-smoke.cpp` exercises the native window in Wine: bootstrap, Send To, file upload/revoke, rename and restart. A physical Windows/Android test remains separate from these checks.

import {spawn,spawnSync} from 'node:child_process';
import {mkdtemp,mkdir,rm,writeFile} from 'node:fs/promises';
import {tmpdir,networkInterfaces} from 'node:os';
import {createInterface} from 'node:readline';
import http from 'node:http';
import dgram from 'node:dgram';
import path from 'node:path';
import assert from 'node:assert/strict';
import {startLanDiscovery,LAN_PORT,LAN_GROUP} from '../scripts/lan-discovery.mjs';
const root=process.cwd(),tools='/workspace/flowdrop-build',jar=tools+'/downloads/json-test.jar',compiled=tools+'/lan-tests';await mkdir(compiled,{recursive:true});
const result=spawnSync('java',['-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-encoding','UTF-8','-cp',jar,'-d',compiled,'android/src/app/flowdrop/mobile/CodeLookup.java','android/src/app/flowdrop/mobile/TransferServer.java','android/src/app/flowdrop/mobile/LanDiscovery.java','tests/LanHostHarness.java'],{encoding:'utf8'});assert.equal(result.status,0,result.stderr);
const iface=Object.values(networkInterfaces()).flat().find(a=>a?.family==='IPv4'&&!a.internal&&!a.address.startsWith('169.254.'));assert.ok(iface,'No LAN IPv4 interface');
const folder=await mkdtemp(path.join(tmpdir(),'flowdrop-lan-')),children=[],servers=[],report=[];let nodeLan,sender;
async function phone(name){const child=spawn('java',['-Xmx96m','-cp',compiled+path.delimiter+jar,'app.flowdrop.mobile.LanHostHarness',path.join(folder,name),iface.address],{stdio:['pipe','pipe','inherit']});children.push(child);const lines=createInterface({input:child.stdout})[Symbol.asyncIterator]();const next=async()=>{const line=await lines.next();assert.equal(line.done,false);const value=JSON.parse(line.value);assert.ok(!value.error,value.error);return value;};const ready=await next();return {...ready,command:async body=>{child.stdin.write(JSON.stringify(body)+'\n');return next();}};}
async function server(config){const server=http.createServer((req,res)=>{res.setHeader('Content-Type','application/json');res.end(JSON.stringify(config));});servers.push(server);await new Promise(r=>server.listen(0,'0.0.0.0',r));return server;}
async function until(check,label){const end=Date.now()+16000;while(Date.now()<end){if(await check())return;await new Promise(r=>setTimeout(r,200));}throw new Error(label);}
try{
 const node=await server({name:'FlowDrop',deviceId:'windows-test',deviceName:'Windows LAN',platform:'windows',version:'1.9.0'});
 nodeLan=startLanDiscovery({deviceId:'windows-test',deviceName:'Windows LAN',port:node.address().port,interfaces:()=>[iface]});
 const [a,b]=await Promise.all([phone('phone-a'),phone('phone-b')]);
 await until(async()=>{const ap=(await a.command({action:'peers'})).peers,bp=(await b.command({action:'peers'})).peers;return ap.some(p=>p.id===b.id)&&ap.some(p=>p.id==='windows-test')&&bp.some(p=>p.id===a.id)&&bp.some(p=>p.id==='windows-test')&&nodeLan.peers().some(p=>p.id===a.id)&&nodeLan.peers().some(p=>p.id===b.id);},'Peers did not discover every other platform without mDNS');
 for(const p of [a,b]){const peers=(await p.command({action:'peers'})).peers;assert.equal(peers.length,2);assert.ok(!peers.some(x=>x.id===p.id));for(const item of peers){const config=await(await fetch(item.url+'/api/config')).json();assert.equal(config.deviceId,item.id);assert.ok(item.port>0);}}
 assert.equal(nodeLan.peers().length,2);report.push('Two production Java LAN engines and Node Windows engine each find both other devices over real UDP/TCP without mDNS; same-name phones remain distinct; self is excluded');
 const fake=await server({name:'Different app',deviceId:'fake-app'});sender=dgram.createSocket('udp4');await new Promise(r=>sender.bind(0,'0.0.0.0',r));sender.setMulticastInterface(iface.address);sender.setMulticastLoopback(true);
 for(const id of ['fake-app','spoofed-device']){const packet=Buffer.from(JSON.stringify({app:'flowdrop',discovery:1,kind:'query',id,name:'Fake',platform:'android',port:fake.address().port}));for(let i=0;i<3;i++)await new Promise((resolve,reject)=>sender.send(packet,LAN_PORT,LAN_GROUP,e=>e?reject(e):resolve()));}
 await new Promise(r=>setTimeout(r,1200));for(const p of [a,b])assert.equal((await p.command({action:'peers'})).peers.length,2);assert.equal(nodeLan.peers().length,2);report.push('Non-FlowDrop HTTP server and mismatched device IDs never enter device lists');
 await b.command({action:'stop'});await until(async()=>!(await a.command({action:'peers'})).peers.some(p=>p.id===b.id)&&!nodeLan.peers().some(p=>p.id===b.id),'Goodbye did not remove stopped phone');
 await b.command({action:'start'});await until(async()=>(await a.command({action:'peers'})).peers.some(p=>p.id===b.id)&&nodeLan.peers().some(p=>p.id===b.id),'Restarted phone not rediscovered');report.push('Device removal and automatic rediscovery after restart; actual dynamically assigned HTTP ports confirmed');
 await writeFile(tools+'/lan-discovery-verification-1.9.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
}finally{nodeLan?.stop();sender?.close();for(const child of children)child.kill();for(const server of servers){server.closeAllConnections();await new Promise(r=>server.close(r));}await Promise.all(children.map(c=>new Promise(r=>c.exitCode!==null?r():c.once('exit',r))));await rm(folder,{recursive:true,force:true});}

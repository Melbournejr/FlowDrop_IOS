// The signing key stays outside source control and outside the release bundle.
import {parseArgs} from 'node:util';
import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {createHash,sign} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import path from 'node:path';
import {APP_VERSION,UPDATE_PUBLIC_KEY} from './release-config.mjs';
import {verifyRelease} from './secure-update.mjs';
const {values}=parseArgs({options:{key:{type:'string'},out:{type:'string'}}});
if(!values.key)throw new Error('Provide --key with the original PRIVATE update signing key path. Never publish the key.');
const directory=path.resolve(values.out||'releases/'+APP_VERSION);await mkdir(directory,{recursive:true});
const repo='https://github.com/Melbournejr/FlowDrop_IOS/releases/download/v'+APP_VERSION;
const manifest=await readFile('android/AndroidManifest.xml','utf8');
if(!manifest.includes('android:versionName="'+APP_VERSION+'"'))throw new Error('Android version differs from Windows release.');
const versionCode=Number(manifest.match(/android:versionCode="(\d+)"/)[1]);
const platforms={},checksums=[];
for(const [platform,name] of [['windows','FlowDrop-Setup-'+APP_VERSION+'-Windows-x64.exe'],['android','FlowDrop-'+APP_VERSION+'-Android.apk']]){
 const bytes=await readFile(path.join('artifacts',name)),sha256=createHash('sha256').update(bytes).digest('hex');await copyFile(path.join('artifacts',name),path.join(directory,name));
 platforms[platform]={version:APP_VERSION,url:repo+'/'+name,size:bytes.length,sha256,...(platform==='android'?{versionCode}:{})};checksums.push(sha256+'  '+name);
}
const payload=JSON.stringify({schema:1,app:'FlowDrop',notes:'Sửa dò Windows trên Android và nhận bằng mã; gửi thư mục ZIP; thêm cập nhật có xác minh chữ ký.',platforms});
const key=await readFile(values.key),envelope={payload,signature:sign('RSA-SHA256',Buffer.from(payload),key).toString('base64')};
verifyRelease(envelope,UPDATE_PUBLIC_KEY);await writeFile(path.join(directory,'latest.json'),JSON.stringify(envelope,null,2)+'\n');
await writeFile(path.join(directory,'SHA256SUMS-release.txt'),checksums.join('\n')+'\n');
const notes=`# FlowDrop ${APP_VERSION}\n\n- Sửa quét Android: thử nhiều IPv4, TXT fallback, dùng từng giao diện Wi-Fi và làm mới khi đổi mạng. Windows có nút thiết lập Firewall cho LAN.\n- Nhận mã 8 ký tự trên các máy cùng Wi-Fi, không cần nhập địa chỉ.\n- Chọn cả thư mục, giữ cây thư mục và thư mục rỗng trong file ZIP/ZIP64.\n- Windows và Android kiểm tra/tải bản mới có chữ ký; chỉ cài khi không truyền file. Android có thể yêu cầu xác nhận của hệ thống.\n\nCài đè 1.10 thủ công một lần để bật updater. Không gỡ bản cũ.\n\nĐăng các file bên trong ZIP này tại https://github.com/Melbournejr/FlowDrop_IOS/releases/new, tag v${APP_VERSION}, loại release chính thức/latest. Đính kèm EXE, APK và latest.json thành các asset riêng, giữ nguyên tên. Không đưa khóa ký vào GitHub.\n`;
await writeFile(path.join(directory,'Release-notes-'+APP_VERSION+'.md'),notes);
const names=[...Object.values(platforms).map(x=>path.basename(x.url)),'latest.json','SHA256SUMS-release.txt','Release-notes-'+APP_VERSION+'.md'];
execFileSync('python',['-c',`import zipfile,sys,pathlib\np=pathlib.Path(sys.argv[1])\nwith zipfile.ZipFile(p/sys.argv[2],'w',zipfile.ZIP_DEFLATED) as z:\n for n in sys.argv[3:]: z.write(p/n,n)`,directory,'FlowDrop-GitHub-Release-'+APP_VERSION+'.zip',...names]);
console.log(JSON.stringify({version:APP_VERSION,versionCode,platforms,bundle:path.join(directory,'FlowDrop-GitHub-Release-'+APP_VERSION+'.zip')},null,2));

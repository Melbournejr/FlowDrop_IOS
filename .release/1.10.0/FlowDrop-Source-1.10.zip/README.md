# FlowDrop 1.10 — Windows và Android native

Chuyển file hai chiều Windows ↔ Android và Android ↔ Android trong cùng Wi-Fi. Giao diện tối, điểm nhấn xanh, dùng Win32/C++ trên Windows và Activity/Widget/Service Java trên Android. Không cần trình duyệt hoặc WebView. Windows đóng gói Node.js 24 x64 để chạy giao thức truyền file; Android dùng máy chủ Java nằm trong APK.

- Tự tìm thiết bị bằng mDNS/DNS-SD và UDP LAN, xác minh lại danh tính qua HTTP. Android thử nhiều IPv4 và TXT hints để tránh chọn nhầm địa chỉ VPN/Ethernet. Windows gửi qua từng giao diện mạng và làm mới khi địa chỉ thay đổi; có nút cấp quyền Firewall cho LAN.
- Chọn thiết bị để gửi, bên nhận xác nhận; phiên truyền hiển thị byte, số file và kết quả lưu. Nhận dự phòng bằng mã 8 ký tự tìm trên các máy FlowDrop được phát hiện trong Wi-Fi, không cần gõ địa chỉ.
- Chọn cả thư mục, đóng gói ZIP/ZIP64 giữ thư mục con và thư mục rỗng. Máy nhận lưu ZIP để giải nén.
- Windows chọn thư mục nhận. Android lưu ảnh/video vào album DCIM/FlowDrop; các file khác vào Download/FlowDrop. Không ghi đè tên và không công khai file nhận dở.
- Bộ cập nhật kiểm tra manifest RSA, SHA-256, phiên bản; APK còn đối chiếu package và khóa ký đang cài. Windows tự cài khi không truyền file. Android dùng PackageInstaller, chờ phiên truyền kết thúc và xử lý xác nhận của hệ điều hành nếu cần. Kênh GitHub Releases chỉ hoạt động sau khi chủ dự án đăng `latest.json` và bộ cài.

Xem [INSTALL.md](INSTALL.md) để cài đè, dùng mã/thư mục, đăng bản đầu tiên lên GitHub và xử lý quyền cập nhật. Mã nguồn iOS/iPadOS 1.0.3 nằm trong `ios/`, giữ nguyên trong lần sửa Windows/Android này.

## Phát triển

Node.js 24 trở lên; `npm ci`, rồi `npm start` để chạy máy chủ LAN. `npm run dev` chỉ nghe trên loopback. Các giao diện web cũ được giữ để phát triển; EXE/APK dùng giao diện native.

```sh
npm test
npm run test:network
npm run test:android-discovery
npm run test:android-host
npm run test:features
```

Các kiểm tra gồm HTTP thật với hai engine Java và Node, mã tra qua nhiều máy, UDP/TCP không cần mDNS, mDNS, tiến độ/lưu file/gián đoạn và chống ghi đè. DeviceDiscovery dùng Android API stubs có kiểm soát cho timeout, đổi mạng và nhiều địa chỉ. Kiểm tra ZIP64 dùng một file hơn 4 GiB và đối chiếu CRC bằng Python; cần khoảng 5 GiB chỗ trống trong `$FLOWDROP_BUILD_TOOLS` (mặc định `/workspace/flowdrop-build`). JVM tests cần JDK 21 và jar org.json riêng tại thư mục tools `downloads/json-test.jar`; APK dùng org.json hệ thống.

Dựng EXE/APK: `python scripts/build-installers.py`. Toolchains: Android SDK 35/JDK 21, MinGW-w64 GCC 14, NSIS 3.11 và Node Windows 24.15.0 x64. Toolchain và khóa APK gốc nằm ngoài checkout, chọn bằng `FLOWDROP_BUILD_TOOLS`. Script không tạo khóa khác khi mất khóa gốc. Cửa sổ Windows được kiểm tra bằng `tests/windows-native-smoke.cpp` trong Wine; APK instrumentation thử dịch vụ/UI nằm riêng ở `tests/android-native-smoke`.

`node scripts/make-release.mjs --key /duong-dan-rieng/update-signing-private.pem` tạo manifest đã ký và gói GitHub Releases từ bộ cài hiện tại. Giữ đúng khóa cập nhật RSA và keystore APK gốc, không đưa chúng hoặc token lên GitHub. Nâng cả version/versionCode khi phát hành tiếp.

`npm run build` tạo trang tải trong `dist/` từ manifest `releases/<version>/manifest.json`, kiểm tra SHA-256 từng file trước khi xuất. Trang tải Sites giữ quyền riêng của chủ sở hữu; kênh cập nhật dùng kho GitHub công khai `Melbournejr/FlowDrop_IOS`. `npm run build:worker` chỉ dành cho Worker/R2 cũ, không phải trang tải đang xuất bản.

## Giới hạn

Không đặt hạn mức sản phẩm 10 file / 50 MiB mỗi file / 200 MiB mỗi lượt. Nội dung truyền theo luồng; giới hạn thực tế là chỗ trống, hệ thống file, mạng và metadata tối đa 8 MiB. Mã có hiệu lực 24 giờ khi máy giữ file còn mở, không dùng để tra file qua Internet. Truyền LAN hiện dùng HTTP, chưa mã hóa đầu cuối.

Đã kiểm tra bản 1.10 trên JVM, Android API stubs và cửa sổ Windows trong Wine; chưa kiểm chứng trên điện thoại Android 16 và Wi-Fi thật của người dùng. Việc chọn thư mục SAF, quyền Firewall/UAC và cài cập nhật nền cần thử trên hệ điều hành thực tế. EXE chưa có chứng thư ký mã nhà phát hành; APK ký bằng khóa riêng của dự án.
